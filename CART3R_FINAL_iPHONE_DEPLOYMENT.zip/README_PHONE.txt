CART3R GOLD INTELLIGENCE — FINAL BUILD 4.0
PHONE-ONLY DEPLOYMENT

You only need the two files in this folder:
  1) app.py
  2) requirements.txt

NO COMPUTER OR XBOX REQUIRED.

ONE-TIME SETUP FROM YOUR IPHONE
1. Open Safari and sign in/create an account at github.com.
2. Create a new repository called cart3r-gold-intelligence.
3. Choose Private if you want the source code kept out of public view.
4. Open the new repository and choose Add file → Upload files.
5. Upload app.py and requirements.txt from this folder. They must be in the repository's top/root level, not inside another folder.
6. Commit the upload.
7. Open https://share.streamlit.io and sign in. Connect/authorise GitHub if asked.
8. Choose Create app → Yup, I have an app.
9. Select your repository, branch main, and main file path app.py.
10. Choose Deploy and wait for the build to finish.
11. Open the new HTTPS app address in Safari. Tap Share → Add to Home Screen.

After that, use the new home-screen icon like an app. The dashboard runs on the hosting service; the phone does not need Python installed.

PRIVACY / SAFETY
- Keep the GitHub repository private if you do not want the source code public.
- Check Streamlit app Sharing settings too; repository privacy and app viewer access are separate settings.
- Never put broker logins, passwords, account numbers or API keys in app.py or requirements.txt.
- This app does not connect to MT5 or place trades.

If Safari's file picker does not let you select both files at once, upload app.py first, then repeat Add file → Upload files for requirements.txt.
